package com.example.tasknotes

import android.app.Application
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import org.json.JSONArray
import org.json.JSONObject

// ---------- Data ----------
data class Item(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val body: String = "",
    val isTask: Boolean = true,
    val done: Boolean = false
)

// ---------- ViewModel (persists to SharedPreferences as JSON) ----------
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("tasknotes", Context.MODE_PRIVATE)
    var items by mutableStateOf(load())
        private set

    private fun load(): List<Item> = try {
        val arr = JSONArray(prefs.getString("items", "[]"))
        List(arr.length()) {
            val o = arr.getJSONObject(it)
            Item(o.getLong("id"), o.getString("title"), o.optString("body"),
                o.optBoolean("isTask", true), o.optBoolean("done"))
        }
    } catch (e: Exception) { emptyList() }

    private fun save() {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title)
                .put("body", it.body).put("isTask", it.isTask).put("done", it.done))
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }

    private fun update(list: List<Item>) { items = list; save() }
    fun add(title: String, body: String, isTask: Boolean) =
        update(listOf(Item(title = title.trim(), body = body.trim(), isTask = isTask)) + items)
    fun toggle(item: Item) = update(items.map { if (it.id == item.id) it.copy(done = !it.done) else it })
    fun delete(item: Item) = update(items.filterNot { it.id == item.id })
}

// ---------- UI ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MainViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) } // 0 = Tasks, 1 = Notes
    var showAdd by remember { mutableStateOf(false) }
    val shown = vm.items.filter { it.isTask == (tab == 0) }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(title = { Text("Rhema") })
                TabRow(selectedTabIndex = tab) {
                    Tab(tab == 0, { tab = 0 }, text = { Text("Tasks") })
                    Tab(tab == 1, { tab = 1 }, text = { Text("Notes") })
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, "Add") }
        }
    ) { pad ->
        if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) {
                Text("Nothing here yet. Tap + to add.")
            }
        } else LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown, key = { it.id }) { item ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (item.isTask) Checkbox(item.done, { vm.toggle(item) })
                        Column(Modifier.weight(1f).padding(horizontal = 4.dp)
                            .clickable(enabled = item.isTask) { vm.toggle(item) }) {
                            Text(item.title, style = MaterialTheme.typography.titleMedium,
                                textDecoration = if (item.done) TextDecoration.LineThrough else null)
                            if (item.body.isNotBlank()) Text(item.body, style = MaterialTheme.typography.bodyMedium)
                        }
                        IconButton({ vm.delete(item) }) { Icon(Icons.Default.Delete, "Delete") }
                    }
                }
            }
        }
    }

    if (showAdd) AddDialog(isTask = tab == 0, onDismiss = { showAdd = false }) { t, b ->
        vm.add(t, b, tab == 0); showAdd = false
    }
}

@Composable
fun AddDialog(isTask: Boolean, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isTask) "New task" else "New note") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true)
                OutlinedTextField(body, { body = it }, label = { Text("Details (optional)") }, minLines = 3)
            }
        },
        confirmButton = { TextButton({ onSave(title, body) }, enabled = title.isNotBlank()) { Text("Save") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}
